Woodworking Planner design geometry set
Revision: rev_d16464aac8334b6382a6afb7b48f8c7e
Project ID: project_6b39706451d0444f8f01fe07e4f39e21
Template: plywood_bookcase_v1 1.0.0
Canonical CAD/CSV units: millimeters. Preview GLB: Y-up meters.
One maintained STEP/GLB per manufactured definition; manifest instances place the panels.
Import project.json into Woodworking Planner to edit this supported project.
Construction status: recipe_unselected. Physical review: not recorded.
CAD represents finished nominal blanks; planned jig/fastener references are not machined voids.
No shelf load rating or public construction approval is implied.
