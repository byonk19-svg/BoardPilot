Woodworking Planner design geometry set
Revision: rev_efaa288f131f47eb92554426e7c77750
Project ID: project_49dcd3ed58704a898f7a2c099168fb98
Template: plywood_bookcase_v1 1.0.0
Canonical CAD/CSV units: millimeters. Preview GLB: Y-up meters.
One maintained STEP/GLB per manufactured definition; manifest instances place the panels.
Import project.json into Woodworking Planner to edit this supported project.
Construction status: recipe_unselected. Physical review: not recorded.
CAD represents finished nominal blanks; planned jig/fastener references are not machined voids.
No shelf load rating or public construction approval is implied.
